﻿using System;

namespace GenericArrayCreator
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] vs = ArrayCreator.Create(5, "Pesho");
        }
    }
}

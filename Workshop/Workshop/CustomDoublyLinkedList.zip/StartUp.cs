﻿using System;
using System.Diagnostics;

namespace CustomLinkedList
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
